//
//  introduction.h
//  cpp
//
//  Created by Bob Nystrom on 8/19/13.
//  Copyright (c) 2013 Bob Nystrom. All rights reserved.
//

#ifndef cpp_introduction_h
#define cpp_introduction_h

//^update
bool update()
{
  // 做点工作……
  return isDone();
}
//^update

#endif
